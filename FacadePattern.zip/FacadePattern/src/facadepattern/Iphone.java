/**
 *  @author zakia
 * @version 1.0
 * @since 0.0
 */
 
package facadepattern;
/**
 *Iphone implements MobileShop class with ModelNo and Price methods
 */
public class Iphone implements MobileShop {  
	/**
     *Over-ride the method of Model Number
     */
	@Override  
    public void modelNo() {  
        System.out.println(" Iphone 6 ");  
    } 
	/**
     *Over-ride the method of Price
     */
    @Override  
    public void price() {  
    System.out.println(" Rs 65000.00 ");  
    }  
}  
    

