
/**
 *  @author zakia
 * @version 1.0
 * @since 0.0
 */
package facadepattern;


/**
 *  giving Interface for Method of Model Number and Price
 */
public interface MobileShop 
{
    public void modelNo();  
    public void price(); 
    
}



