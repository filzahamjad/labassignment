
/**
 *  @author zakia
 * @version 1.0
 * @since 0.0
 */
package facadepattern;
/**
 *samsung implements MobileShop class with ModelNo and Price methods
 */
public class Samsung implements MobileShop {  

	/**
     *Over-ride the method of Model Number
     */
    @Override  
    public void modelNo() {  
    	
    System.out.println(" Samsung galaxy tab 3 ");  
    } 
    /**
     *Over-ride the method of Price
     */
    @Override  
    public void price() {  
        System.out.println(" Rs 45000.00 ");  
    }  
}  
