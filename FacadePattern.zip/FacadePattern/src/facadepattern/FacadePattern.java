/**
 *  @author zakia
 * @version 1.0
 * @since 0.0
 */
package facadepattern;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;




public class FacadePattern {
	/**
	 * @author zakia
	 * @param args
	 * @throws NumberFormatException
	 * @throws IOException
	 */
private static int  choice;
   
    public static void main(String args[])throws NumberFormatException,IOException {
        
        do{       
            System.out.print("========= Mobile Shop ============ \n");  
            System.out.print("            1. IPHONE.              \n");  
            System.out.print("            2. SAMSUNG.              \n");  
            System.out.print("            3. BLACKBERRY.            \n");  
            System.out.print("            4. Exit.                     \n");  
            System.out.print("Enter your choice: ");  
              
            BufferedReader br=new BufferedReader(new InputStreamReader(System.in));  
            choice=Integer.parseInt(br.readLine());  
            ShopKeeper sk=new ShopKeeper();  
              
            /**
             *Using cases statements for sale of each phone
             */
            switch (choice) {  
            case 1:  
                {   
                  sk.iphoneSale();  
                    }  
                break;  
       case 2:  
                {  
                  sk.samsungSale();        
                    }  
                break;    
       case 3:  
                           {  
                           sk.blackberrySale();       
                           }  
                   break;     
            default:  
            {    
                System.out.println(" You purchased Nothing.");  
            }         
                return;  
            }  
              
      }while(choice!=4);  
   }  
        
    }
    

