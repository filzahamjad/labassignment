
/**
 * @author zakia
 * @version 1.0
 * @since 0.0
 */
package facadepattern;
/** Creates an ShopKeepr with the specified mobile name.
*/
public class ShopKeeper {  
	
	private MobileShop iphone;  
    private MobileShop samsung;  
    private MobileShop blackberry;  
      
    /**
     * Instantiate the 3 classes of Iphone, Samsung and Blackberry
     */
    public ShopKeeper(){  
        iphone= new Iphone();  
        samsung=new Samsung();  
        blackberry=new Blackberry();  
    }  
    
    /**
     * Method of Iphone sale
     */
    public void iphoneSale(){  
        iphone.modelNo();  
        iphone.price();  
    }  
    /**
     * Method of Samsung sale
     */
        public void samsungSale(){  
        samsung.modelNo();  
        samsung.price();  
    }  
        /**
         * Method of blackberry sale
         */
   public void blackberrySale(){  
    blackberry.modelNo();  
    blackberry.price();  
        }  
}  